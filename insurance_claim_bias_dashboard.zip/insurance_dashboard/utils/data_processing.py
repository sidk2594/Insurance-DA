"""
Data loading, cleaning and feature engineering utilities for the
Insurance Claim Settlement Bias Analysis dashboard.
"""

import pandas as pd
import numpy as np
import streamlit as st

REQUIRED_COLUMNS = [
    "POLICY_NO", "PI_GENDER", "SUM_ASSURED", "ZONE", "PAYMENT_MODE",
    "EARLY_NON", "PI_OCCUPATION", "MEDICAL_NONMED", "PI_STATE",
    "REASON_FOR_CLAIM", "PI_AGE", "PI_ANNUAL_INCOME", "POLICY_STATUS",
]


def validate_columns(df: pd.DataFrame):
    """Check the uploaded file has the columns this app expects."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    return missing


def _clean_numeric_string(series: pd.Series) -> pd.Series:
    """Convert Indian-formatted numeric strings ('1,68,300') to floats."""
    return (
        series.astype(str)
        .str.replace(",", "", regex=False)
        .str.strip()
        .replace({"": np.nan, "nan": np.nan})
        .astype(float)
    )


@st.cache_data(show_spinner=False)
def load_and_clean(file_bytes: bytes) -> pd.DataFrame:
    """Load the raw CSV bytes and return a cleaned, feature-enriched dataframe."""
    import io
    df = pd.read_csv(io.BytesIO(file_bytes))

    df["SUM_ASSURED"] = _clean_numeric_string(df["SUM_ASSURED"])
    df["PI_ANNUAL_INCOME"] = _clean_numeric_string(df["PI_ANNUAL_INCOME"])

    # Target: binary outcome. "Approved Death Claim" -> 1, "Repudiate Death" -> 0
    df["STATUS_BIN"] = df["POLICY_STATUS"].astype(str).str.contains("Approved", case=False).astype(int)

    # Missing-value handling for categoricals
    df["PI_OCCUPATION"] = df["PI_OCCUPATION"].fillna("Unknown")
    df["REASON_FOR_CLAIM"] = df["REASON_FOR_CLAIM"].fillna("Not Specified")

    # Age bands
    bins_age = [0, 30, 45, 60, 150]
    labels_age = ["<30", "30-45", "45-60", "60+"]
    df["AGE_BAND"] = pd.cut(df["PI_AGE"], bins=bins_age, labels=labels_age)

    # Income bands. ~60% of records have PI_ANNUAL_INCOME == 0, which is a
    # data-quality / non-disclosure issue rather than a true zero income, so
    # it gets its own bucket instead of distorting the quantile cuts.
    nonzero = df.loc[df["PI_ANNUAL_INCOME"] > 0, "PI_ANNUAL_INCOME"]
    if len(nonzero) >= 10:
        q1, q2 = nonzero.quantile([0.33, 0.66]).values
    else:
        q1, q2 = 0, 0

    def _income_band(x):
        if x == 0 or pd.isna(x):
            return "Not Disclosed"
        elif x <= q1:
            return "Low"
        elif x <= q2:
            return "Mid"
        else:
            return "High"

    df["INCOME_BAND"] = df["PI_ANNUAL_INCOME"].apply(_income_band)
    income_band_order = ["Not Disclosed", "Low", "Mid", "High"]
    df["INCOME_BAND"] = pd.Categorical(df["INCOME_BAND"], categories=income_band_order, ordered=True)

    return df


def reduce_cardinality(series: pd.Series, top_n: int = 12) -> pd.Series:
    """Collapse rare categories into 'Other' to keep one-hot encoding manageable."""
    top = series.value_counts().nlargest(top_n).index
    return series.where(series.isin(top), "Other")


def engineer_features(df: pd.DataFrame, cardinality_top_n: int = 12):
    """
    Build the model-ready feature matrix X and target y.
    Returns X (one-hot encoded), y, and the list of raw categorical/numeric
    columns used, for transparency in the UI.
    """
    work = df.copy()

    work["ZONE_R"] = reduce_cardinality(work["ZONE"], cardinality_top_n)
    work["STATE_R"] = reduce_cardinality(work["PI_STATE"], cardinality_top_n)
    work["OCC_R"] = reduce_cardinality(work["PI_OCCUPATION"], cardinality_top_n)
    work["REASON_R"] = reduce_cardinality(work["REASON_FOR_CLAIM"], cardinality_top_n)

    cat_cols = ["PI_GENDER", "ZONE_R", "PAYMENT_MODE", "EARLY_NON",
                "OCC_R", "MEDICAL_NONMED", "STATE_R", "REASON_R"]
    num_cols = ["SUM_ASSURED", "PI_AGE", "PI_ANNUAL_INCOME"]

    X = pd.get_dummies(work[cat_cols + num_cols], columns=cat_cols, drop_first=True)
    y = work["STATUS_BIN"]

    meta = {"cat_cols": cat_cols, "num_cols": num_cols, "n_features": X.shape[1]}
    return X, y, meta
