"""
Statistical diagnostic utilities for bias investigation.

The philosophy here: raw approval-rate gaps between groups can be driven by
confounders (claim amount, cause of death, payment mode, etc.) rather than
the group itself. So in addition to raw chi-square association tests, this
module fits a logistic regression that controls for those confounders, and
reports whether a sensitive attribute (age / income / team) still has a
significant, independent effect on approval odds once they're accounted for.
"""

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, chi2
import statsmodels.api as sm


def cramers_v(confusion_matrix: pd.DataFrame) -> float:
    """Effect size for a chi-square test of association (0=none, 1=perfect)."""
    chi2_stat = chi2_contingency(confusion_matrix)[0]
    n = confusion_matrix.sum().sum()
    r, k = confusion_matrix.shape
    if n == 0 or min(r - 1, k - 1) == 0:
        return np.nan
    phi2 = chi2_stat / n
    return float(np.sqrt(phi2 / min(r - 1, k - 1)))


def association_table(df: pd.DataFrame, target_col: str, group_cols: list) -> pd.DataFrame:
    """Chi-square test + Cramer's V for each grouping variable vs the target."""
    rows = []
    for col in group_cols:
        ct = pd.crosstab(df[col], df[target_col])
        if ct.shape[0] < 2:
            continue
        chi2_stat, p, dof, _ = chi2_contingency(ct)
        v = cramers_v(ct)
        rows.append({
            "Variable": col,
            "Chi2": round(chi2_stat, 2),
            "p_value": p,
            "Cramers_V": round(v, 3),
            "Significant (p<0.05)": "Yes" if p < 0.05 else "No",
        })
    return pd.DataFrame(rows).sort_values("p_value")


def group_rate_table(df: pd.DataFrame, group_col: str, target_col: str, min_n: int = 10) -> pd.DataFrame:
    """Approval rate, count, and a 95% Wilson-ish CI proxy per group."""
    g = df.groupby(group_col)[target_col].agg(["mean", "count"]).rename(
        columns={"mean": "approval_rate", "count": "n"}
    )
    g = g.reset_index()
    g["reliable (n>={})".format(min_n)] = g["n"] >= min_n
    return g.sort_values("approval_rate", ascending=False)


def controlled_logit(df: pd.DataFrame, sensitive_col: str, sensitive_kind: str,
                      control_cats: list, top_n_categories: int = 10):
    """
    Fit two logistic regressions: a base model with only confounders/control
    variables, and a full model that adds the sensitive attribute. Used to test
    whether the sensitive attribute has an effect on approval odds *independent*
    of the legitimate claim-related controls.

    sensitive_kind: 'numeric' (e.g. PI_AGE, PI_ANNUAL_INCOME) or
                     'categorical' (e.g. ZONE / team)

    Returns a dict with the LR test p-value (does the attribute matter at all,
    jointly) and a per-category/coefficient breakdown with odds ratios and p-values.
    """
    work = df.copy()

    def _reduce(s, top_n):
        top = s.value_counts().nlargest(top_n).index
        return s.where(s.isin(top), "Other")

    # Build control matrix
    work["_REASON_R"] = _reduce(work["REASON_FOR_CLAIM"], 8)
    cat_map = {"REASON_FOR_CLAIM": "_REASON_R"}
    control_use = [cat_map.get(c, c) for c in control_cats]

    X_base = pd.get_dummies(work[control_use], drop_first=True)
    X_base["SUM_ASSURED_LAKH"] = work["SUM_ASSURED"] / 100000.0
    X_base = sm.add_constant(X_base).astype(float)
    y = work["STATUS_BIN"].astype(float)

    base_model = sm.Logit(y, X_base).fit(disp=0, maxiter=200)

    if sensitive_kind == "numeric":
        extra = work[[sensitive_col]].astype(float)
        if sensitive_col == "PI_ANNUAL_INCOME":
            extra = extra / 100000.0
            extra.columns = ["PI_ANNUAL_INCOME_LAKH"]
        X_full = pd.concat([X_base, extra], axis=1).astype(float)
    else:
        work["_SENS_R"] = _reduce(work[sensitive_col], top_n_categories)
        dummies = pd.get_dummies(work["_SENS_R"], prefix=sensitive_col, drop_first=True)
        X_full = pd.concat([X_base, dummies], axis=1).astype(float)

    full_model = sm.Logit(y, X_full).fit(disp=0, maxiter=200)

    lr_stat = 2 * (full_model.llf - base_model.llf)
    df_diff = max(full_model.df_model - base_model.df_model, 1)
    p_lr = chi2.sf(lr_stat, df_diff)

    new_cols = [c for c in X_full.columns if c not in X_base.columns]
    coefs = full_model.params[new_cols]
    pvals = full_model.pvalues[new_cols]
    breakdown = pd.DataFrame({
        "coef": coefs,
        "odds_ratio": np.exp(coefs),
        "p_value": pvals,
    }).sort_values("p_value")

    return {
        "lr_stat": lr_stat,
        "lr_pvalue": p_lr,
        "df_diff": df_diff,
        "breakdown": breakdown,
        "base_model": base_model,
        "full_model": full_model,
    }
