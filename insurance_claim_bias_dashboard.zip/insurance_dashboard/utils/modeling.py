"""
Modeling utilities: train KNN / Decision Tree / Random Forest / Gradient
Boosting classifiers on the engineered feature matrix and compute the full
set of evaluation artifacts (accuracy, precision/recall/F1, ROC, confusion
matrix, feature importance).
"""

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix,
)


def get_model_specs(knn_k=15, dt_depth=7, rf_depth=10, rf_trees=200, gb_trees=150, gb_depth=3):
    return {
        "KNN": (KNeighborsClassifier(n_neighbors=knn_k), True),
        "Decision Tree": (DecisionTreeClassifier(max_depth=dt_depth, class_weight="balanced", random_state=42), False),
        "Random Forest": (RandomForestClassifier(n_estimators=rf_trees, max_depth=rf_depth,
                                                   class_weight="balanced", random_state=42, n_jobs=-1), False),
        "Gradient Boosting": (GradientBoostingClassifier(n_estimators=gb_trees, max_depth=gb_depth, random_state=42), False),
    }


@st.cache_data(show_spinner=False)
def train_and_evaluate(X: pd.DataFrame, y: pd.Series, test_size=0.25, random_state=42, model_kwargs=None):
    """
    Train all four classifiers and return a dict of per-model results plus
    the shared train/test split so the UI can render ROC curves, confusion
    matrices, etc.
    """
    model_kwargs = model_kwargs or {}
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    specs = get_model_specs(**model_kwargs)
    results = {}

    for name, (model, needs_scaling) in specs.items():
        Xtr = X_train_s if needs_scaling else X_train
        Xte = X_test_s if needs_scaling else X_test

        model.fit(Xtr, y_train)
        train_pred = model.predict(Xtr)
        test_pred = model.predict(Xte)
        test_proba = model.predict_proba(Xte)[:, 1]

        fpr, tpr, _ = roc_curve(y_test, test_proba)
        cm = confusion_matrix(y_test, test_pred)

        feat_importance = None
        if hasattr(model, "feature_importances_"):
            feat_importance = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)

        results[name] = {
            "model": model,
            "train_acc": accuracy_score(y_train, train_pred),
            "test_acc": accuracy_score(y_test, test_pred),
            "precision": precision_score(y_test, test_pred, zero_division=0),
            "recall": recall_score(y_test, test_pred, zero_division=0),
            "f1": f1_score(y_test, test_pred, zero_division=0),
            "auc": roc_auc_score(y_test, test_proba),
            "fpr": fpr,
            "tpr": tpr,
            "confusion_matrix": cm,
            "feature_importance": feat_importance,
        }

    return {
        "results": results,
        "X_train": X_train, "X_test": X_test,
        "y_train": y_train, "y_test": y_test,
    }


def metrics_dataframe(results: dict) -> pd.DataFrame:
    rows = []
    for name, r in results.items():
        rows.append({
            "Model": name,
            "Train Accuracy": r["train_acc"],
            "Test Accuracy": r["test_acc"],
            "Precision": r["precision"],
            "Recall": r["recall"],
            "F1 Score": r["f1"],
            "ROC AUC": r["auc"],
            "Overfit Gap (Train-Test Acc)": r["train_acc"] - r["test_acc"],
        })
    return pd.DataFrame(rows).set_index("Model")
